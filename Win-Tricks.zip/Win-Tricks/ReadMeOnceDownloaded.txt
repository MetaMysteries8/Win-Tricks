Read Me!

Hi, these are a few windows tricks I learned from videos!
If you like messing with .bat and .vbs files, this is for you!
This is a zip file full of a bunch of tricks I made and they can be used to
make using you computer easier or just to mess around! I hope you enjoy
the package of tricks! You may now continue to use these windows
programs made in only .bat and .vbs files!